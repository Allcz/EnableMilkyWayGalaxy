# EnableMilkyWayGalaxy

## Features

- 
- Unlock the milky way and achievements even if you are using mods.

- 即使使用mod也可以 解锁银河系、解锁成就。


## Changelog

### v1.1.3
- Bugs fixed.

### v1.1.2
- Updated to work with game version 0.9.25.11985 or higher.

### v1.1.1
- Bugs fixed.

### v1.1.0
- Updated to work with game version 0.9.24.11209 or higher.

### v1.0.9
- Refactor the code.

### v1.0.8
- Updated to work with game version 0.8.23.9989 or higher.

### v1.0.7
- Updated to work with game version 0.8.23.9808 or higher.

### v1.0.6
- Fixed the milky way server rejecting the data when the total of sails which launch to Dyson sphere is zero.

### v1.0.5
- Fixed one mistake what I made in the last version.

### v1.0.4
- Refactor the code.

### v1.0.3
- Enables unlocking achievements even if it is not your game save.

### v1.0.2
- Enables unlocking achievements even if mods are used now.
- Refactor the code

### v1.0.1
- Updated to work with game version 0.8.22.9331 or higher.

### v1.0.0
- Initial release.
